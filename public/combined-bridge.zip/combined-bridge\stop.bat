@echo off
REM ============================================================================
REM  stop.bat  -  Stop the combined-bridge relay.
REM  Force-kills whatever process OWNS the relay ports (9191 thermal, 9192 QR)
REM  via Get-NetTCPConnection -> Stop-Process. This is exact (only those ports,
REM  never your dev server) and reliable - no netstat text parsing. Also ends
REM  the scheduled task so it won't relaunch.
REM ============================================================================
setlocal

schtasks /End /TN "Combined Bridge" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p = Get-NetTCPConnection -LocalPort 9191,9192 -State Listen -ErrorAction SilentlyContinue | Select-Object -Expand OwningProcess -Unique; if ($p) { $p | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }; Write-Host 'Relay stopped.' } else { Write-Host 'Relay was not running.' }"

endlocal
