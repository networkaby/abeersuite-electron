@echo off
REM ============================================================================
REM  stop.bat  -  Stop the combined-bridge relay.
REM  Force-kills whatever process OWNS the relay ports (9191 thermal, 9192 QR,
REM  5000 ePBX — all one process now) via Get-NetTCPConnection -> Stop-Process.
REM  This is exact (only those ports, never your dev server) and reliable - no
REM  netstat text parsing. Also ends the scheduled task so it won't relaunch.
REM ============================================================================
setlocal

schtasks /End /TN "Combined Bridge" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p = Get-NetTCPConnection -LocalPort 9191,9192,5000 -State Listen -ErrorAction SilentlyContinue | Select-Object -Expand OwningProcess -Unique; if ($p) { $p | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }; Write-Host 'Relay stopped.' } else { Write-Host 'Relay was not running.' }"

endlocal
