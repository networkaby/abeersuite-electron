' Launches the Combined Bridge with NO visible terminal window.
' Used by Windows autostart (setup-autostart.bat registers a Task Scheduler
' entry that runs this on logon). Safe to double-click directly too.
' Needs Node on PATH - the installer puts it there.

Option Explicit

Dim shell, fso, scriptDir
Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = scriptDir

' 0 = SW_HIDE (no window at all), False = don't wait for completion.
shell.Run "cmd /c node """ & scriptDir & "\index.js""", 0, False
