// Combined Bridge — single Node process that boots the thermal-printer relay
// (port 9191), the QR-display relay (port 9192), and the ePBX call-log listener
// (TCP 5000) from one shared config.json. Each sub-module receives an injected
// accessor pair so it can read/write its own slice without knowing the others.

const fs   = require("fs");
const path = require("path");

const CONFIG_PATH = path.join(__dirname, "config.json");

function loadAll() {
    if (!fs.existsSync(CONFIG_PATH)) {
        console.error("ERROR: config.json not found next to index.js.");
        process.exit(1);
    }
    try {
        return JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
    } catch (e) {
        console.error("ERROR: config.json is not valid JSON.", e.message);
        process.exit(1);
    }
}

function saveAll(full) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(full, null, 2), "utf8");
}

/** One accessor pair per top-level key in config.json. */
function makeAccessors(key) {
    return {
        getConfig: () => {
            const full = loadAll();
            return full[key] || {};
        },
        setConfig: (partial) => {
            const full = loadAll();
            full[key] = { ...(full[key] || {}), ...partial };
            saveAll(full);
            return full[key];
        },
    };
}

console.log("Combined Bridge starting...");
require("./thermal").start(makeAccessors("thermal"));
require("./qr").start(makeAccessors("qr"));
require("./epbx").start(makeAccessors("epbx"));
