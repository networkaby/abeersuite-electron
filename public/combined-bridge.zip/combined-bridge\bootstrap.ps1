<#
 bootstrap.ps1  -  Ensure Node is installed system-wide, then install deps.
 Used by the ONLINE installer's [Run] step and by update.bat.

 Node (so the bare `node` in start-hidden.vbs resolves at logon):
   1. system Node on PATH and >= v18      -> use as-is, install nothing
   2. bundled node-setup.msi (offline)    -> msiexec install (no internet)
   3. else download the MSI from nodejs.org and install   (online)
   Installing Node system-wide needs admin - the installer runs elevated.

 Dependencies (only when node_modules is absent - the offline payload ships
 them, and update.bat deletes node_modules first to force a fresh install):
   pnpm if it's installed (honours the lockfile + onlyBuiltDependencies),
   otherwise npm. npm/pnpm both build serialport + sharp here.
#>
$ErrorActionPreference = 'Stop'
$app     = $PSScriptRoot
$nodeVer = 'v22.11.0'
$msiUrl  = "https://nodejs.org/dist/$nodeVer/node-$nodeVer-x64.msi"
$nodeDir = Join-Path $env:ProgramFiles 'nodejs'

function Test-Node {
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) { return $false }
    if ((& node -v) -match '^v(\d+)') { return ([int]$Matches[1] -ge 18) }
    return $false
}

# -- 1) Ensure system Node --------------------------------------------------
if (Test-Node) {
    Write-Host "Node: using system Node ($(node -v)) - nothing to install."
} else {
    $bundled = Join-Path $app 'node-setup.msi'
    if (Test-Path $bundled) {
        Write-Host "Node: installing bundled MSI (offline) ..."
        $msi = $bundled
    } else {
        Write-Host "Node: not found - downloading $nodeVer MSI ..."
        $msi = Join-Path $env:TEMP "node-$nodeVer-x64.msi"
        Invoke-WebRequest $msiUrl -OutFile $msi
    }
    $p = Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Node MSI install failed (msiexec exit $($p.ExitCode))" }
    # Make the freshly-installed node visible to THIS process for the npm step.
    if (Test-Path (Join-Path $nodeDir 'node.exe')) { $env:Path = "$nodeDir;$env:Path" }
    if (-not (Test-Node)) { throw "Node still not on PATH after install." }
    Write-Host "Node installed: $(node -v)"
}

# -- 2) Install dependencies (only if missing) ------------------------------
if (Test-Path (Join-Path $app 'node_modules')) {
    Write-Host "Dependencies: node_modules present - skipping install."
} else {
    $pm = if (Get-Command pnpm -ErrorAction SilentlyContinue) { 'pnpm' } else { 'npm' }
    Write-Host "Dependencies: installing with $pm ..."
    Push-Location $app
    try {
        & $pm install
        if ($LASTEXITCODE -ne 0) { throw "$pm install failed ($LASTEXITCODE)" }
    } finally { Pop-Location }
}

Write-Host "Bootstrap complete."
