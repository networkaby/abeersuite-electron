@echo off
REM ─────────────────────────────────────────────────────────────────────────
REM  register-autostart.bat  -  Non-interactive autostart registration.
REM  Same effect as setup-autostart.bat but WITHOUT the pause prompts, so the
REM  installer (combined-bridge.iss) can call it silently. Registers a Task
REM  Scheduler ONLOGON task that launches the bridge hidden, then starts it now.
REM  No admin required (per-user task).
REM ─────────────────────────────────────────────────────────────────────────
setlocal
set "TASK=Combined Bridge"
set "VBS=%~dp0start-hidden.vbs"

if not exist "%VBS%" exit /b 1

schtasks /Create /TN "%TASK%" /TR "wscript.exe \"%VBS%\"" /SC ONLOGON /F >nul 2>&1
schtasks /Run    /TN "%TASK%" >nul 2>&1
exit /b 0
