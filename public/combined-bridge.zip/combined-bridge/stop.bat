@echo off
REM ============================================================================
REM  stop.bat  -  Stop the combined-bridge relay
REM  Kills whatever Node process is LISTENING on the relay ports:
REM    9191 = thermal printer (ESC/POS)   9192 = DQ11 QR display
REM  Safe: only targets processes bound to those exact ports.
REM ============================================================================
setlocal enabledelayedexpansion
set "FOUND="
for %%P in (9191 9192) do (
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P " ^| findstr LISTENING') do (
        echo Stopping PID %%a  (port %%P)
        taskkill /F /PID %%a >nul 2>&1
        set "FOUND=1"
    )
)
if defined FOUND (
    echo Relay stopped.
) else (
    echo Relay was not running.
)
endlocal
