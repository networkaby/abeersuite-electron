@echo off
REM Start the combined-bridge relay (visible window — shows errors / logs).
cd /d "%~dp0"
if exist "%~dp0node\node.exe" (
    "%~dp0node\node.exe" index.js
) else (
    node index.js
)
pause
