<#
 bootstrap.ps1  -  First-run setup for the ONLINE installer.
 Downloads a local Node into .\node\ (if not already present) and installs the
 bridge's npm dependencies with it. The OFFLINE installer ships node\ +
 node_modules already, so it never runs this.
 Self-contained: no system Node, no admin, no PATH changes.
#>
$ErrorActionPreference = 'Stop'
$app     = $PSScriptRoot
$nodeVer = 'v22.11.0'
$nodeUrl = "https://nodejs.org/dist/$nodeVer/node-$nodeVer-win-x64.zip"
$nodeDir = Join-Path $app 'node'

if (-not (Test-Path (Join-Path $nodeDir 'node.exe'))) {
    Write-Host "Downloading Node $nodeVer ..."
    $zip = Join-Path $env:TEMP 'cb-node.zip'
    Invoke-WebRequest $nodeUrl -OutFile $zip
    $tmp = Join-Path $env:TEMP 'cb-node'
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    Expand-Archive $zip $tmp -Force
    $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
    if (Test-Path $nodeDir) { Remove-Item $nodeDir -Recurse -Force }
    Move-Item $inner.FullName $nodeDir
    Remove-Item $zip -Force
}

Write-Host "Installing dependencies..."
Push-Location $app
try {
    & (Join-Path $nodeDir 'npm.cmd') install
    if ($LASTEXITCODE -ne 0) { throw "npm install failed ($LASTEXITCODE)" }
} finally {
    Pop-Location
}
Write-Host "Bootstrap complete."
