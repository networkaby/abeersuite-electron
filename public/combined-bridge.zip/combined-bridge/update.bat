@echo off
REM ============================================================================
REM  update.bat  -  Update the bridge in place (double-click inside the install
REM  folder). Stops the relay, downloads the latest code from the office app,
REM  re-installs deps with the local Node, and restarts. Keeps config.json and
REM  the local node\ folder. Needs internet; offline machines re-run the offline
REM  installer instead.
REM ============================================================================
setlocal
cd /d "%~dp0"
set "APP=https://office.networkservice.in"

echo Stopping bridge...
call "%~dp0stop.bat"

echo Downloading latest bridge from %APP% ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; $z=Join-Path $env:TEMP 'cb-upd.zip'; $t=Join-Path $env:TEMP 'cb-upd'; Invoke-WebRequest '%APP%/combined-bridge.zip' -OutFile $z; if(Test-Path $t){Remove-Item $t -Recurse -Force}; Expand-Archive $z $t -Force; Copy-Item (Join-Path $t 'combined-bridge\*') '%~dp0' -Recurse -Force; Remove-Item $z,$t -Recurse -Force"
if errorlevel 1 ( echo. & echo Update failed ^(no internet?^). Relay left as-is. & pause & exit /b 1 )

echo Installing dependencies...
if exist "%~dp0node\npm.cmd" (
    call "%~dp0node\npm.cmd" install
) else (
    call npm install
)

echo Restarting bridge...
call "%~dp0register-autostart.bat"

echo.
echo Update complete.
pause
