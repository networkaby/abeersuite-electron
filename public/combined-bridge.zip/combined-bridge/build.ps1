<#
============================================================================
 build.ps1  -  Build the bridge installer (.exe), code zip and version manifest
 into the local dist\ folder (self-contained — no dependency on where the web
 app repo lives). Optionally also copy them into the web app's public\ folder.

 Run on a dev machine with Inno Setup 6 installed, from the bridge repo:
   powershell -ExecutionPolicy Bypass -File build.ps1
   # …or build AND publish to the web app in one go:
   powershell -ExecutionPolicy Bypass -File build.ps1 -PublicDir 'D:\AbeerSuite\service-mgmt-experiment\public'

 Release steps:
   1. bump "version" in package.json   (the ONLY version you edit)
   2. run this script
   3. copy dist\* into the web app's public\ (or pass -PublicDir), commit + deploy

 Params:
   -OutDir     where artifacts are written (default: <bridge>\dist)
   -PublicDir  optional web app public\ folder to also copy artifacts into
   -Iscc       path to Inno Setup's ISCC.exe
============================================================================
#>
[CmdletBinding()]
param(
    [string]$OutDir    = (Join-Path $PSScriptRoot 'dist'),
    [string]$PublicDir = '',
    [string]$Iscc      = 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe'
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

$version = (Get-Content (Join-Path $root 'package.json') -Raw | ConvertFrom-Json).version
Write-Host "Building combined-bridge v$version" -ForegroundColor Cyan

if (-not (Test-Path $Iscc)) { throw "ISCC not found: $Iscc  (install Inno Setup 6)" }
New-Item -ItemType Directory -Force $OutDir | Out-Null

# 1) Installer .exe  (Inno Setup; /O overrides the .iss OutputDir to $OutDir)
Write-Host "1/3  Compiling installer..."
& $Iscc "/O$OutDir" (Join-Path $root 'combined-bridge.iss') | Out-Null

# 2) Code-only .zip  (no .git / node_modules — deps come from npm install on the PC)
Write-Host "2/3  Building zip..."
$stage = Join-Path $env:TEMP 'cb-build'
$cb    = Join-Path $stage 'combined-bridge'
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force $cb | Out-Null
robocopy $root $cb /E /XD .git node_modules dist .pnpm-store .qodo /XF *.iss /NFL /NDL /NJH /NJS /NP | Out-Null
# robocopy: exit codes 0-7 are success, 8+ are failure — normalise.
if ($LASTEXITCODE -ge 8) { throw "robocopy failed (code $LASTEXITCODE)" }
$global:LASTEXITCODE = 0
$zip = Join-Path $OutDir 'combined-bridge.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path $cb -DestinationPath $zip

# 3) Version manifest  (matches package.json so the app's update check works)
Write-Host "3/3  Stamping version manifest..."
$manifest = @"
{
  "version": "$version"
}
"@
Set-Content -Path (Join-Path $OutDir 'combined-bridge.version.json') -Value $manifest -Encoding ascii

# Optional: publish straight into the web app's public\ folder.
if ($PublicDir) {
    if (-not (Test-Path $PublicDir)) { throw "PublicDir not found: $PublicDir" }
    foreach ($f in 'combined-bridge-setup.exe','combined-bridge.zip','combined-bridge.version.json') {
        Copy-Item (Join-Path $OutDir $f) (Join-Path $PublicDir $f) -Force
    }
    Write-Host "Published to $PublicDir" -ForegroundColor Green
}

Write-Host "Done (v$version). Artifacts in $OutDir :" -ForegroundColor Green
Write-Host "  combined-bridge-setup.exe"
Write-Host "  combined-bridge.zip"
Write-Host "  combined-bridge.version.json"
