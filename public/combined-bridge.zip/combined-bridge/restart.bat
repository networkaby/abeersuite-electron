@echo off
REM ============================================================================
REM  restart.bat  -  Stop then start the combined-bridge relay
REM  Run this after pulling new relay code (thermal.js / qr.js) so the running
REM  process picks up the changes. Opens the relay in its own window so you can
REM  watch its logs; close that window (or run stop.bat) to stop it.
REM ============================================================================
cd /d "%~dp0"

echo --- Stopping any running relay ---
call "%~dp0stop.bat"

echo.
echo --- Starting combined-bridge relay (thermal :9191 + QR :9192) ---
timeout /t 1 /nobreak >nul
start "combined-bridge relay" cmd /k "cd /d "%~dp0" && node index.js"

echo Relay launched in a new window.
