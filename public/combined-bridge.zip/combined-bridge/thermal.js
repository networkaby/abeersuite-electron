// Thermal printer relay (ESC/POS). Listens on cfg.relayPort (default 9191).
// Endpoints kept identical to the standalone thermal-relay so the web app
// (PrinterSettingsPage + voucher print buttons) doesn't need any changes.

const express  = require("express");
const cors     = require("cors");
const fs       = require("fs");
const path     = require("path");
const os       = require("os");
const net      = require("net");
const { exec } = require("child_process");
const sharp    = require("sharp");
const { ThermalPrinter, PrinterTypes, CharacterSet } = require("node-thermal-printer");

// ── Logo raster ────────────────────────────────────────────────────────────────
// The browser receipt shows the org logo via <img>; to keep the ESC/POS slip on
// the SAME template, fetch that logoUrl, downscale to the printable width, flatten
// to mono-friendly grayscale, and hand node-thermal-printer a temp PNG. Cached by
// url+width so we don't re-download every print. Best-effort: any failure → no logo.
const _logoCache = new Map();
async function logoToTempPng(url, widthPx) {
    const key = `${url}@${widthPx}`;
    if (_logoCache.has(key)) return _logoCache.get(key);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`logo fetch ${res.status}`);
    const png = await sharp(Buffer.from(await res.arrayBuffer()))
        .resize({ width: widthPx, withoutEnlargement: true })
        .flatten({ background: "#ffffff" })   // drop alpha — thermal paper is white
        .grayscale()
        .png()
        .toBuffer();
    const file = path.join(os.tmpdir(), `pos-logo-${Buffer.from(key).toString("hex").slice(0, 16)}.png`);
    await fs.promises.writeFile(file, png);
    _logoCache.set(key, file);
    return file;
}

// ── Struck-MRP raster ───────────────────────────────────────────────────────────
// ESC/POS has no strike-through text style, so to show the MRP crossed out (like
// the browser receipt) we render the sub-line to a tiny mono PNG with a line
// through the price and print it as a raster. Cached by text. Best-effort: the
// caller falls back to plain "MRP <amt>" text if this throws.
const _strikeCache = new Map();
async function strikeMrpPng(label, priceStr) {
    const key = `${label}|${priceStr}`;
    if (_strikeCache.has(key)) return _strikeCache.get(key);
    const fontSz = 22;                       // px (named to avoid shadowing the `fs` module)
    const cw   = fontSz * 0.6;               // monospace char width ≈ 0.6em
    const padX = 12;                         // left indent (matches the "  MRP" inset)
    const text = `${label} ${priceStr}`;
    const w    = Math.ceil(text.length * cw) + padX + 6;
    const h    = 34;
    const numStart = padX + (label.length + 1) * cw;       // strike only the number
    const numEnd   = numStart + priceStr.length * cw;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">`
        + `<rect width="100%" height="100%" fill="#fff"/>`
        + `<text x="${padX}" y="24" font-family="monospace" font-size="${fontSz}" fill="#000">${text}</text>`
        + `<line x1="${numStart}" y1="16" x2="${numEnd}" y2="16" stroke="#000" stroke-width="2"/>`
        + `</svg>`;
    const png  = await sharp(Buffer.from(svg)).png().toBuffer();
    const file = path.join(os.tmpdir(), `pos-mrp-${Buffer.from(key).toString("hex").slice(0, 20)}.png`);
    await fs.promises.writeFile(file, png);
    _strikeCache.set(key, file);
    return file;
}

// ── ESC/POS receipt builder ───────────────────────────────────────────────────

function buildReceiptBuffer(data, companyName) {
    const printer = new ThermalPrinter({
        type:         PrinterTypes.EPSON,
        interface:    "tcp://127.0.0.1:9999",
        characterSet: CharacterSet.PC437_USA,
    });

    const { reference, date, type, party, narration, lines, totalDebit, totalCredit, status, createdBy } = data;

    const fmtAmt = (n) =>
        Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    const formattedDate = date
        ? new Date(date).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })
        : "";

    printer.alignCenter();
    printer.bold(true);
    printer.setTextSize(1, 1);
    printer.println(companyName || "My Company");
    printer.setTextNormal();
    printer.bold(false);
    printer.println("VOUCHER");
    printer.drawLine();

    printer.alignLeft();
    printer.tableCustom([
        { text: `Ref: ${reference}`, align: "LEFT",  width: 0.6 },
        { text: formattedDate,        align: "RIGHT", width: 0.4 },
    ]);
    printer.println(`Type: ${(type || "").replace(/_/g, " ")}`);
    if (party) printer.println(`Party: ${party}`);
    printer.drawLine();

    printer.tableCustom([
        { text: "Account", align: "LEFT",  width: 0.5 },
        { text: "Dr",      align: "RIGHT", width: 0.25 },
        { text: "Cr",      align: "RIGHT", width: 0.25 },
    ]);
    printer.drawLine();

    for (const line of lines || []) {
        const amt = fmtAmt(line.amount);
        const dr  = line.type === "DEBIT"  ? amt : "";
        const cr  = line.type === "CREDIT" ? amt : "";
        printer.tableCustom([
            { text: line.accountName || "", align: "LEFT",  width: 0.5 },
            { text: dr,                     align: "RIGHT", width: 0.25 },
            { text: cr,                     align: "RIGHT", width: 0.25 },
        ]);
        if (line.description) printer.println("  " + line.description);
    }

    printer.drawLine();
    printer.bold(true);
    printer.tableCustom([
        { text: "Total",             align: "LEFT",  width: 0.5 },
        { text: fmtAmt(totalDebit),  align: "RIGHT", width: 0.25 },
        { text: fmtAmt(totalCredit), align: "RIGHT", width: 0.25 },
    ]);
    printer.bold(false);
    printer.drawLine();

    if (narration) {
        printer.println(`Note: ${narration}`);
        printer.drawLine();
    }

    printer.println(`Status: ${status || ""}   By: ${createdBy || ""}`);
    printer.println(`Printed: ${new Date().toLocaleString("en-GB")}`);
    printer.cut();

    return printer.getBuffer();
}

// ── Payment / Receipt voucher builder (POS "Rcv" + collect-on-the-go surplus) ──
// Prints the money side of a counter receipt: who paid, the tender breakdown
// (cash / UPI / card — one row each), the total received, and how it was applied
// (old dues cleared / advance). For a POS overpayment the sale slip carries NO
// tenders — they live here.
function buildPaymentBuffer(data, companyName) {
    const printer = new ThermalPrinter({
        type:         PrinterTypes.EPSON,
        interface:    "tcp://127.0.0.1:9999",
        characterSet: CharacterSet.PC437_USA,
    });

    const { reference, date, party, tenders, total, arrear, advance, note,
            title, partyLabel, totalLabel } = data;

    const fmtAmt = (n) =>
        Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const formattedDate = date
        ? new Date(date).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })
        : "";

    printer.alignCenter();
    printer.bold(true);
    printer.setTextSize(1, 1);
    printer.println(companyName || "My Company");
    printer.setTextNormal();
    printer.bold(false);
    printer.println(title || "PAYMENT RECEIPT");
    printer.drawLine();

    printer.alignLeft();
    printer.tableCustom([
        { text: `No: ${reference || ""}`, align: "LEFT",  width: 0.55 },
        { text: formattedDate,            align: "RIGHT", width: 0.45 },
    ]);
    if (party) printer.println(`${partyLabel || "Received from"}: ${party}`);
    printer.drawLine();

    // Tender breakdown — the money side lives here now (not on the sale slip).
    for (const tnd of tenders || []) {
        printer.tableCustom([
            { text: tnd.label || "",   align: "LEFT",  width: 0.6 },
            { text: fmtAmt(tnd.amount), align: "RIGHT", width: 0.4 },
        ]);
    }
    printer.drawLine();

    printer.bold(true);
    printer.tableCustom([
        { text: totalLabel || "Received", align: "LEFT",  width: 0.5 },
        { text: "Rs. " + fmtAmt(total),   align: "RIGHT", width: 0.5 },
    ]);
    printer.bold(false);
    printer.drawLine();

    if (Number(arrear) > 0)
        printer.tableCustom([{ text: "Cleared old dues", align: "LEFT", width: 0.6 }, { text: fmtAmt(arrear), align: "RIGHT", width: 0.4 }]);
    if (Number(advance) > 0)
        printer.tableCustom([{ text: "Advance / credit", align: "LEFT", width: 0.6 }, { text: fmtAmt(advance), align: "RIGHT", width: 0.4 }]);
    if (Number(arrear) > 0 || Number(advance) > 0) printer.drawLine();

    if (note) { printer.println(note); printer.drawLine(); }

    printer.alignCenter();
    if ((totalLabel || "Received") === "Received") printer.println("Received with thanks");
    printer.println(`Printed: ${new Date().toLocaleString("en-GB")}`);
    printer.cut();

    return printer.getBuffer();
}

// ── POS receipt builder ───────────────────────────────────────────────────────

async function buildPosBuffer(data, companyName) {
    const { invoiceNumber, date, customerName, customerGstin, lines, subtotal, discountPct, discountAmount, tax, total, cashPaid, upiPaid, extrasPaid, grossAtTag, discounts, charges, savings, hsnSummary, template: tpl } = data;

    // Resolved POS voucher print template (header/address/toggles/terms/footer).
    // Sent by PosScreen (via /api/pos/sale → posTemplate) so this slip matches
    // /receipt/invoice/[id]?kind=POS. Older clients omit it → safe fallbacks.
    const t = {
        headerLine1:    "",
        headerLine2:    "POS sale receipt",
        addressBlock:   "",
        gstinLine:      "",
        phoneLine:      "",
        logoUrl:        "",
        showLogo:       false,
        showAddress:    true,
        showGstin:      true,
        showPhone:      true,
        showTaxSummary: true,
        showMrp:        true,
        showSignature:  false,
        signatureLabel: "Authorised Signatory",
        termsText:      "",
        footerLine:     "Thank you · Visit again",
        paperWidthMm:   80,
        ...(tpl || {}),
    };

    // Usable columns from the paper size. An "80mm" head prints ~72mm wide = 48
    // columns (Font A); a "58mm" head prints ~48mm = 32. paperWidthMm may carry
    // either the roll width (80 / 58) or the printable width (72 / 48), so treat
    // anything ~70mm+ as the wide class. node-thermal-printer's tableCustom emits
    // one column more than configured, so keep a 2-column safety margin (wide →
    // 46, narrow → 30) or right-aligned amounts wrap their last digit.
    const mm        = Number(t.paperWidthMm) || 80;
    const cols      = mm >= 70 ? 48 : 32;
    const charWidth = cols - 2;
    const nameWidth = Math.floor(charWidth * 0.5) - 1;

    const printer = new ThermalPrinter({
        type:         PrinterTypes.EPSON,
        interface:    "tcp://127.0.0.1:9999",
        characterSet: CharacterSet.PC437_USA,
        width:        charWidth,
    });

    // Ladder mode: POS sends the customer-facing "Counter discount" ladder
    // (Gross-at-tag → discount rows → Total → You saved). Older / non-ladder
    // payloads have no grossAtTag → fall back to the legacy Subtotal/Discount/Tax.
    const ladderMode = grossAtTag != null && Array.isArray(discounts);

    const fmtAmt = (n) =>
        Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    const formattedDate = date
        ? new Date(date).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })
        : "";
    const formattedTime = date
        ? new Date(date).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })
        : "";

    // ── Header (template-driven) ──────────────────────────────────────────
    printer.alignCenter();
    // Logo (same template as the browser receipt). Best-effort — a fetch/raster
    // failure or a printer without image support must never block the slip.
    if (t.showLogo && t.logoUrl) {
        try {
            const logoFile = await logoToTempPng(t.logoUrl, cols >= 48 ? 360 : 240);
            await printer.printImage(logoFile);
        } catch (err) {
            console.warn("[thermal:pos] logo skipped:", err.message);
        }
    }
    printer.bold(true);
    printer.setTextSize(1, 1);
    printer.println(t.headerLine1 || companyName || "My Company");
    printer.setTextNormal();
    printer.bold(false);
    if (t.headerLine2) printer.println(t.headerLine2);
    if (t.showAddress && t.addressBlock) {
        for (const ln of String(t.addressBlock).split("\n").map((s) => s.trim()).filter(Boolean))
            printer.println(ln);
    }
    if (t.showPhone && t.phoneLine) printer.println(t.phoneLine);
    if (t.showGstin && t.gstinLine) printer.println(t.gstinLine);
    printer.drawLine();

    printer.alignLeft();
    printer.println(`Invoice: ${invoiceNumber}`);
    printer.tableCustom([
        { text: `Date: ${formattedDate}`, align: "LEFT",  width: 0.6 },
        { text: formattedTime,             align: "RIGHT", width: 0.4 },
    ]);
    printer.println(`Customer: ${customerName || "Walk-in"}`);
    if (customerGstin) printer.println(`GSTIN: ${customerGstin}`);
    printer.drawLine();

    printer.tableCustom([
        { text: "Item",   align: "LEFT",  width: 0.5 },
        { text: "Qty",    align: "RIGHT", width: 0.15 },
        { text: "Amount", align: "RIGHT", width: 0.35 },
    ]);
    printer.drawLine();

    for (const line of lines || []) {
        const name = String(line.name || "").slice(0, nameWidth);
        const qty  = Number(line.qty) || 0;
        // Ladder mode shows the public tag (barcode) total as the line amount; the
        // real per-item price stays pooled in "Counter discount" below.
        const lineAmt = ladderMode && line.barcode != null ? line.barcode * qty : line.amount;
        printer.tableCustom([
            { text: name,              align: "LEFT",  width: 0.5 },
            { text: String(line.qty),  align: "RIGHT", width: 0.15 },
            { text: fmtAmt(lineAmt),   align: "RIGHT", width: 0.35 },
        ]);
        // MRP reference, struck through (rasterized — escpos has no strike-through
        // text style). Gated by the template's showMrp toggle. Falls back to plain
        // text if the raster fails.
        if (ladderMode && t.showMrp && line.mrp != null && line.mrp * qty > lineAmt) {
            try {
                const f = await strikeMrpPng("MRP", fmtAmt(line.mrp * qty));
                printer.alignLeft();
                await printer.printImage(f);
            } catch (err) {
                console.warn("[thermal:pos] MRP strike raster skipped:", err.message);
                printer.tableCustom([
                    { text: `  MRP ${fmtAmt(line.mrp * qty)}`, align: "LEFT", width: 1 },
                ]);
            }
        }
    }

    printer.drawLine();

    if (ladderMode) {
        // Gross-at-tag → "Counter discount" + tier/loyalty/coupon rows → (HSN) → Total.
        printer.tableCustom([
            { text: "Gross",            align: "LEFT",  width: 0.55 },
            { text: fmtAmt(grossAtTag), align: "RIGHT", width: 0.45 },
        ]);
        for (const d of discounts) {
            printer.tableCustom([
                { text: String(d.label || "Discount").slice(0, 22), align: "LEFT",  width: 0.55 },
                { text: `-${fmtAmt(d.amount)}`,                      align: "RIGHT", width: 0.45 },
            ]);
        }
        // Bill-level adjustments (shipping/round-off/manual) — signed.
        if (Array.isArray(charges)) {
            for (const c of charges) {
                printer.tableCustom([
                    { text: String(c.label || "Charge").slice(0, 22),                   align: "LEFT",  width: 0.55 },
                    { text: `${c.amount < 0 ? "-" : "+"}${fmtAmt(Math.abs(c.amount))}`,  align: "RIGHT", width: 0.45 },
                ]);
            }
        }
    } else if (t.showTaxSummary) {
        printer.tableCustom([
            { text: "Subtotal", align: "LEFT",  width: 0.55 },
            { text: fmtAmt(subtotal), align: "RIGHT", width: 0.45 },
        ]);
        if (discountPct > 0) {
            printer.tableCustom([
                { text: `Discount (${discountPct}%)`, align: "LEFT",  width: 0.55 },
                { text: `-${fmtAmt(discountAmount)}`, align: "RIGHT", width: 0.45 },
            ]);
        }
        if (tax > 0) {
            printer.tableCustom([
                { text: "Tax",        align: "LEFT",  width: 0.55 },
                { text: fmtAmt(tax), align: "RIGHT", width: 0.45 },
            ]);
        }
    }
    printer.drawLine();
    printer.bold(true);
    printer.tableCustom([
        { text: "TOTAL",       align: "LEFT",  width: 0.55 },
        { text: fmtAmt(total), align: "RIGHT", width: 0.45 },
    ]);
    printer.bold(false);
    // GST is INCLUDED in the inclusive amounts above — shown as a note on the
    // total (not a column row, so the running math reads correctly).
    if (ladderMode && t.showTaxSummary && Array.isArray(hsnSummary) && hsnSummary.length > 0) {
        const gst = hsnSummary.reduce((s, h) => s + (h.cgst || 0) + (h.sgst || 0), 0);
        if (gst > 0.005) {
            printer.tableCustom([
                { text: "incl. GST (CGST+SGST)", align: "LEFT",  width: 0.6 },
                { text: fmtAmt(gst),              align: "RIGHT", width: 0.4 },
            ]);
        }
    }
    printer.bold(true);
    if (ladderMode && savings && savings.amount > 0) {
        printer.tableCustom([
            { text: "You saved", align: "LEFT",  width: 0.55 },
            { text: `${fmtAmt(savings.amount)} (${savings.pct}%)`, align: "RIGHT", width: 0.45 },
        ]);
    }
    printer.bold(false);
    printer.drawLine();

    if (cashPaid > 0) {
        printer.tableCustom([
            { text: "Cash",           align: "LEFT",  width: 0.55 },
            { text: fmtAmt(cashPaid), align: "RIGHT", width: 0.45 },
        ]);
    }
    if (upiPaid > 0) {
        printer.tableCustom([
            { text: "UPI",           align: "LEFT",  width: 0.55 },
            { text: fmtAmt(upiPaid), align: "RIGHT", width: 0.45 },
        ]);
    }
    for (const e of extrasPaid || []) {
        if (e.amount > 0) {
            const label = e.method.replace(/_/g, " ");
            printer.tableCustom([
                { text: label,           align: "LEFT",  width: 0.55 },
                { text: fmtAmt(e.amount), align: "RIGHT", width: 0.45 },
            ]);
        }
    }
    const change = Math.max(0, (cashPaid || 0) - total);
    if (change > 0) {
        printer.tableCustom([
            { text: "Change",       align: "LEFT",  width: 0.55 },
            { text: fmtAmt(change), align: "RIGHT", width: 0.45 },
        ]);
    }

    printer.drawLine();

    // ── Terms / signature / footer (template-driven) ──────────────────────
    if (t.termsText) {
        printer.alignLeft();
        for (const ln of String(t.termsText).split("\n")) printer.println(ln);
        printer.drawLine();
    }
    if (t.showSignature) {
        printer.println("");
        printer.println("");
        printer.alignRight();
        printer.println(t.signatureLabel || "Authorised Signatory");
        printer.alignLeft();
    }
    printer.alignCenter();
    printer.println(t.footerLine || "Thank you · Visit again");
    printer.cut();

    return printer.getBuffer();
}

// ── Send buffer ───────────────────────────────────────────────────────────────

function sendNetwork(ip, port, buffer) {
    return new Promise((resolve, reject) => {
        const client = net.createConnection({ host: ip, port: Number(port) }, () => {
            client.write(buffer, (err) => {
                if (err) { client.destroy(); return reject(err); }
                client.end();
                resolve();
            });
        });
        client.setTimeout(5000, () => { client.destroy(); reject(new Error("Network timeout")); });
        client.on("error", reject);
    });
}

function sendCom(comPort, buffer) {
    return new Promise((resolve, reject) => {
        try {
            const { SerialPort } = require("serialport");
            const port = new SerialPort({ path: comPort, baudRate: 9600 });
            port.on("open", () => {
                port.write(buffer, (err) => {
                    if (err) { port.close(); return reject(err); }
                    port.drain(() => { port.close(); resolve(); });
                });
            });
            port.on("error", reject);
        } catch {
            reject(new Error("serialport not available. Run: pnpm install"));
        }
    });
}

function sendWindows(printerName, buffer) {
    return new Promise((resolve, reject) => {
        const tmpFile  = path.join(os.tmpdir(), `receipt-${Date.now()}.bin`);
        const psScript = path.join(__dirname, "print-raw.ps1");
        fs.writeFileSync(tmpFile, buffer);
        exec(
            `powershell -NoProfile -ExecutionPolicy Bypass -File "${psScript}" -PrinterName "${printerName}" -FilePath "${tmpFile}"`,
            (err, stdout, stderr) => {
                fs.unlink(tmpFile, () => {});
                if (err) return reject(new Error(stderr.trim() || err.message));
                const out = stdout.trim();
                if (out !== "OK") return reject(new Error(out || "Print failed"));
                resolve();
            }
        );
    });
}

async function sendBuffer(cfg, buffer) {
    const type = cfg.connectionType || "network";
    if (type === "network") {
        if (!cfg.printerIp || cfg.printerIp === "192.168.1.x")
            throw new Error("Printer IP not configured. Go to Printer Settings.");
        await sendNetwork(cfg.printerIp, cfg.printerPort || 9100, buffer);
    } else if (type === "com") {
        if (!cfg.comPort)
            throw new Error("COM port not configured. Go to Printer Settings.");
        await sendCom(cfg.comPort, buffer);
    } else if (type === "windows") {
        if (!cfg.windowsPrinterName)
            throw new Error("Windows printer name not configured. Go to Printer Settings.");
        await sendWindows(cfg.windowsPrinterName, buffer);
    } else {
        throw new Error(`Unknown connectionType: ${type}`);
    }
}

// ── List helpers ──────────────────────────────────────────────────────────────

function listWindowsPrinters() {
    return new Promise((resolve) => {
        exec("wmic printer get Name /format:list", (err, stdout) => {
            if (err) return resolve([]);
            const names = stdout
                .split(/\r?\n/)
                .map((l) => l.replace(/^Name=/, "").trim())
                .filter(Boolean);
            resolve(names);
        });
    });
}

function listComPorts() {
    return new Promise((resolve) => {
        try {
            const { SerialPort } = require("serialport");
            SerialPort.list()
                .then((ports) => resolve(ports.map((p) => p.path)))
                .catch(() => resolve([]));
        } catch {
            exec("wmic path Win32_SerialPort get DeviceID /format:list", (err, stdout) => {
                if (err) return resolve([]);
                const ids = stdout
                    .split(/\r?\n/)
                    .map((l) => l.replace(/^DeviceID=/, "").trim())
                    .filter(Boolean);
                resolve(ids);
            });
        }
    });
}

// ── start() — boots the thermal Express app ──────────────────────────────────

function start({ getConfig, setConfig }) {
    const app = express();
    app.use(cors());
    app.use(express.json());

    const initialCfg = getConfig();
    const RELAY_PORT = process.env.THERMAL_RELAY_PORT || initialCfg.relayPort || 9191;

    app.get("/health", (_req, res) => {
        const cfg = getConfig();
        res.json({
            ok:                 true,
            connectionType:     cfg.connectionType || "network",
            printerIp:          cfg.printerIp,
            printerPort:        cfg.printerPort,
            comPort:            cfg.comPort,
            windowsPrinterName: cfg.windowsPrinterName,
        });
    });

    app.get("/config", (_req, res) => {
        try { res.json(getConfig()); }
        catch (err) { res.status(500).json({ error: err.message }); }
    });

    app.post("/config", (req, res) => {
        try {
            const updated = setConfig(req.body || {});
            console.log("[thermal:config] updated:", req.body);
            res.json({ ok: true, config: updated });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    });

    app.get("/printers", async (_req, res) => res.json(await listWindowsPrinters()));
    app.get("/ports",    async (_req, res) => res.json(await listComPorts()));

    app.post("/print", async (req, res) => {
        const { reference, lines } = req.body;
        if (!reference || !lines)
            return res.status(400).json({ error: "Missing required fields: reference, lines" });

        const cfg = getConfig();
        try {
            const buffer = buildReceiptBuffer(req.body, cfg.companyName || "My Company");
            await sendBuffer(cfg, buffer);
            console.log(`[thermal] Printed: ${reference}`);
            res.json({ ok: true });
        } catch (err) {
            console.error("[thermal] print error:", err.message);
            res.status(503).json({ error: err.message || "Print failed" });
        }
    });

    app.post("/print/pos", async (req, res) => {
        const { invoiceNumber, lines } = req.body;
        if (!invoiceNumber || !lines)
            return res.status(400).json({ error: "Missing required fields: invoiceNumber, lines" });

        const cfg = getConfig();
        try {
            const buffer = await buildPosBuffer(req.body, cfg.companyName || "My Company");
            await sendBuffer(cfg, buffer);
            console.log(`[thermal] POS printed: ${invoiceNumber}`);
            res.json({ ok: true });
        } catch (err) {
            console.error("[thermal] POS print error:", err.message);
            res.status(503).json({ error: err.message || "Print failed" });
        }
    });

    app.post("/print/payment", async (req, res) => {
        const { reference } = req.body;
        if (!reference)
            return res.status(400).json({ error: "Missing required field: reference" });

        const cfg = getConfig();
        try {
            const buffer = buildPaymentBuffer(req.body, cfg.companyName || "My Company");
            await sendBuffer(cfg, buffer);
            console.log(`[thermal] Payment printed: ${reference}`);
            res.json({ ok: true });
        } catch (err) {
            console.error("[thermal] payment print error:", err.message);
            res.status(503).json({ error: err.message || "Print failed" });
        }
    });

    app.listen(RELAY_PORT, () => {
        const cfg = getConfig();
        console.log(`[thermal] running on http://localhost:${RELAY_PORT}`);
        console.log(`[thermal] connection: ${cfg.connectionType || "network"}`);
        if ((cfg.connectionType || "network") === "network") console.log(`[thermal] printer: ${cfg.printerIp}:${cfg.printerPort || 9100}`);
        if (cfg.connectionType === "com")     console.log(`[thermal] COM port: ${cfg.comPort}`);
        if (cfg.connectionType === "windows") console.log(`[thermal] windows printer: ${cfg.windowsPrinterName}`);
    });
}

module.exports = { start, buildPosBuffer, buildReceiptBuffer, buildPaymentBuffer };
