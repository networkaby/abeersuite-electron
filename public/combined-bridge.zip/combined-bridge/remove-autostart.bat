@echo off
REM Removes the Combined Bridge autostart entry and stops any running copy.

setlocal
set TASK=Combined Bridge

echo Stopping running bridge...
schtasks /End /TN "%TASK%" >nul 2>&1

echo Removing scheduled task...
schtasks /Delete /TN "%TASK%" /F >nul 2>&1
if errorlevel 1 (
    echo No scheduled task to remove.
) else (
    echo Removed.
)

echo.
echo Note: if node.exe is still running, end it via Task Manager -^> Details.
echo.
pause
