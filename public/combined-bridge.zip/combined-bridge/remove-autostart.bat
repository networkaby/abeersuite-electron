@echo off
REM Removes the Combined Bridge autostart entry and stops the running relay.

setlocal
set "TASK=Combined Bridge"

echo Stopping running bridge...
REM Actually kill node.exe (by port) — ending the scheduled task alone leaves
REM the bridge process running.
call "%~dp0stop.bat"

echo.
echo Removing scheduled task...
schtasks /Delete /TN "%TASK%" /F >nul 2>&1
if errorlevel 1 (
    echo No scheduled task to remove.
) else (
    echo Removed.
)

echo.
pause
