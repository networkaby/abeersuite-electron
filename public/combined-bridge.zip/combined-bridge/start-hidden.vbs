' Launches the Combined Bridge with NO visible terminal window.
' Used by Windows autostart (register-autostart.bat / setup-autostart.bat
' register a Task Scheduler entry that runs this on logon). Safe to
' double-click directly too. Prefers the bundled node\ if present.

Option Explicit

Dim shell, fso, scriptDir, nodeExe
Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = scriptDir

' Use the bundled / installed local Node if present, else fall back to PATH.
nodeExe = scriptDir & "\node\node.exe"
If Not fso.FileExists(nodeExe) Then nodeExe = "node"

' 0 = SW_HIDE (no window at all), False = don't wait for completion.
shell.Run "cmd /c """ & nodeExe & """ """ & scriptDir & "\index.js""", 0, False
