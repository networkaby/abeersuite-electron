# Combined Bridge

A single Node.js process that runs on the **shop PC** and bridges the cloud-hosted web app to two pieces of shop hardware at once:

- **Thermal printer (ESC/POS)** — receipts and voucher printouts → `http://localhost:9191`
- **DQ11 QR display** — customer-facing 320×480 USB LCD → `http://localhost:9192`

Both bridges run in one Node process from one folder, sharing a single `config.json`, one autostart entry, one set of dependencies. Endpoints are identical to the standalone `thermal-relay` and `qr-display` tools — the web app talks to `localhost:9191` and `localhost:9192` exactly as before.

```
Browser (cloud app)  ─┬─►  http://localhost:9191/*    (thermal)
                      └─►  http://localhost:9192/*    (qr display)
                                      │
                                      ▼
                          one Node process (index.js)
                                  │       │
                                  ▼       ▼
                              thermal.js  qr.js
```

## Setup (one time)

1. **Install Node.js** (LTS) on the shop PC — https://nodejs.org
2. **Copy this folder** to the PC (e.g. `C:\combined-bridge\`)
3. **Install dependencies**:
   ```
   cd C:\combined-bridge
   pnpm install
   ```
4. **Edit `config.json`** — set the thermal printer connection and the DQ11 COM port (see below)
5. **Drop idle photos** into `assets\idle\` (or set `qr.idleFolder` to an absolute path)
6. **Stop the standalone relays if they're still running** — both bind ports 9191 / 9192 and can't share. Either:
   - Run `remove-autostart.bat` in each old folder, then reboot
   - Or end their `node.exe` processes via Task Manager
7. **Install autostart**: double-click `setup-autostart.bat` (registers a hidden ONLOGON task). It will start the bridge immediately.

Test:
- `http://localhost:9191/health` → `{ ok: true, connectionType: "...", ... }`
- `http://localhost:9192/health` → `{ ok: true, comPort: "COM5", ... }`

## config.json

```json
{
  "thermal": {
    "connectionType":     "windows",          // "network" | "com" | "windows"
    "printerIp":          "192.168.1.x",
    "printerPort":        9100,
    "comPort":            "COM3",
    "windowsPrinterName": "80mm Series Printer",
    "companyName":        "Network Service",
    "relayPort":          9191
  },
  "qr": {
    "comPort":            "COM5",             // DQ11 serial port (Device Manager → Ports)
    "baudRate":           921600,
    "relayPort":          9192,
    "companyName":        "Network Service",
    "upiPayeeVpa":        "shop@hdfc",
    "upiPayeeName":       "Network Service",
    "idleFolder":         "D:\\shop-ads",     // empty = use bundled assets/idle/
    "idleIntervalMs":     5000,
    "thankyouDurationMs": 4000
  }
}
```

`config.json` is gitignored — it stays on the shop PC only.

The web app's **Printer Settings** and **QR Display Settings** pages POST flat objects to `/config` on each port; the bridge maps each onto its slice and writes the whole file back. Both pages keep working unchanged.

## HTTP API

### Thermal (`:9191`)

| Method | Path | Effect |
|---|---|---|
| GET  | `/health`     | `{ ok, connectionType, printerIp, comPort, windowsPrinterName }` |
| GET  | `/config`     | current `thermal` slice |
| POST | `/config`     | merge + persist (web settings page) |
| GET  | `/printers`   | list of installed Windows printers |
| GET  | `/ports`      | list of available COM ports |
| POST | `/print`         | legacy voucher receipt (journal-style debit/credit lines) |
| POST | `/print/pos`     | POS tax invoice (line items + totals + payments) |
| POST | `/print/payment` | money receipt / payment voucher (party · tenders · received/paid) |
| POST | `/print/voucher` | any office voucher **and** the repair-shop documents (see below) |

Every print job carries a resolved **print template** (`payload.template`) and a
`sample` (and, for the bespoke documents, a `body`). The bridge rebuilds the same
ESC/POS slip the browser `ThermalReceiptPreview` renders, honouring the template's
header/footer toggles: brand · address · **email · website** · GSTIN · phone,
terms, **Bank Details + scan-to-pay UPI QR** (`showBank`), signature, footer and
**disclaimer** lines, plus a scannable CODE128 of the reference (`showBarcode`).

`/print/voucher` is kind-aware (from `payload.kind`) and mirrors each browser
middle: generic Item/Qty invoices, the **CONTRA / JOURNAL** Dr/Cr journal, the
**BANK_DEPOSIT / CASH_HANDOVER** denomination worksheet (from `sample.depositSlip`),
the **REPAIR_TICKET** job body and the **SHIPPING_SLIP** service body (both from
`payload.body`). The house rule is bridge-first: a thermal print always tries this
relay, then falls back to the browser print of the identical document.

### QR display (`:9192`)

| Method | Path | Effect |
|---|---|---|
| GET  | `/health`         | `{ ok, comPort, baudRate, idle:{running,files} }` |
| GET  | `/config`         | current `qr` slice |
| POST | `/config`         | merge + persist |
| GET  | `/ports`          | available COM ports (with descriptions) |
| POST | `/pos/customer`   | welcome card with tier / loyalty / outstanding |
| POST | `/pos/cart`       | cart screen with running total |
| POST | `/pos/payment`    | total / cash paid / balance due |
| POST | `/pos/upi`        | builds `upi://pay?…` and renders the QR |
| POST | `/pos/thankyou`   | green thank-you, then auto-resumes slideshow |
| POST | `/idle/start`     | (re)start the slideshow now |
| POST | `/clear`          | black screen |

## DQ11 protocol (for reference)

- 320 × 480 raw RGB565, **307,200 bytes** total
- **Big-endian** (MSB first), no framing
- Image is **vertically flipped** before sending (DQ11's row 0 is at the bottom)
- USB serial @ **921,600 baud**

Reference Python: `qr_display/qr_display_refector_mult_file/qr_utils.py` (`convert_to_rgb565` + `np.flipud`).

## Run hidden + autostart on Windows logon

| File | What it does |
|---|---|
| `start.bat` | Visible window — for testing. |
| `start-hidden.vbs` | Launches the bridge with **no terminal window**. Safe to double-click. |
| `setup-autostart.bat` | Registers Task Scheduler entry → hidden on every logon. **Double-click once.** |
| `remove-autostart.bat` | Undoes the autostart entry and stops the running bridge. |

**One-time install:** double-click `setup-autostart.bat`. It registers the task and starts the bridge immediately. Test the two `/health` endpoints.

**To stop:** Task Manager → Details → end `node.exe`. Or run `remove-autostart.bat` + reboot for permanent removal.

**To update code:** `remove-autostart.bat` → replace files → `setup-autostart.bat`.

## Troubleshooting

| Problem | Fix |
|---|---|
| `EADDRINUSE :9191` or `:9192` | Old standalone relay still running. Stop it (Task Manager) before launching this. |
| Thermal: "Printer IP not configured" | Edit `config.thermal.printerIp` or open Thermal Printer Settings in the web app. |
| QR: "Opening COM6: File not found" | Wrong COM port — the DQ11 enumerated as a different number. `GET /ports` to list. |
| QR: "Device is Ready" on screen | Bridge isn't reaching the DQ11. Check the relay console (or run `start.bat` instead of hidden) for `[qr]` errors. |
| QR: image upside down | Vertical flip is on by default; if you patched it off, turn it back on. |
| QR colours look wrong | DQ11 expects big-endian RGB565; verify the pack formula in `qr.js`. |
| Idle slideshow doesn't start | Check `qr.idleFolder` exists and has `.jpg`/`.png` files. Watch the console for `[qr:idle]` errors. |
| `sharp` install fails on Windows | Run `pnpm install` from PowerShell, not Git Bash; sharp has prebuilt binaries for Win x64. |
