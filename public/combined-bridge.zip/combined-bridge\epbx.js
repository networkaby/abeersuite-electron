// ePBX call-log relay — the third module of the combined bridge.
//
// A TCP SMDR listener (default :5000) that the shop's Matrix NENX / SARVAM PBX
// connects to and streams call records over. Each record is parsed, appended to
// calls.log / calls_raw.log, and POSTed to the cloud CRM (/api/calls).
//
// Unlike thermal.js / qr.js (inbound HTTP relays the browser calls), this one is
// the opposite direction — the PBX pushes IN over raw TCP, and we push OUT to the
// cloud. It shares the bridge's process, config.json (the "epbx" slice), and
// autostart. Its config slice: { pbx:{host,port}, crm:{enabled,url,apiKey,retryCount}, logs:{callsLog,rawLog} }.

const net   = require("net");
const fs    = require("fs");
const path  = require("path");
const os    = require("os");
const http  = require("http");
const https = require("https");

// Physical PC this bridge runs on. Sent with every call record so the CRM can
// show which counter machine pushed it — and, by extension, which bridges are
// still alive. Read once: the hostname can't change while the process runs.
const SOURCE_HOST = os.hostname();

// ── Matrix Posting Protocol control characters ────────────────────────────────
const ENQ = 0x05, ACK = 0x06, NAK = 0x15;
const STX = 0x02, ETX = 0x03, EOT = 0x04;

// ── Record type detection ─────────────────────────────────────────────────────
function detectType(raw) {
    if (raw.startsWith("IN")) return "internal";
    if (/\d+\.\d+\s+[RUru]$/.test(raw)) return "og";
    // Status letter varies by call outcome — N/C/B seen originally, T and U
    // confirmed in live data (previously misclassified as unknown). Widened to
    // exactly the letters verified against production data, not a blanket
    // [A-Za-z] — an unseen letter should still surface as unknown for review.
    if (/\s[NnCcBbTtUu]$/.test(raw)) return "ic";
    return "unknown";
}

// ── Parsers (field positions from live Matrix NENX 312 raw data) ──────────────
//
//  OG: "42     24     C001 9954999271         29-04-26 17:22:46    12    1    1.10  R"
//  IC: "3 0918011930932    C001      22 29-04-26   16:22:38  11   0    25 N"
//  IN: "IN         22               21          29-04-2026  16:29:18     16"

function parseOG(r) {
    // The serial isn't padded to a fixed width either (same issue as IC's serial):
    // it's digits followed by exactly 5 spaces before fromExt, so its length varies
    // (1 digit early, 2+ later). The original fixed offsets were calibrated against
    // a 2-digit serial sample; every downstream field must shift with actual serial
    // length or a short/long serial misaligns everything after it (lost/garbled
    // dialedNumber, wrong date).
    const m = /^(\d+)/.exec(r);
    const delta = m[1].length - 2; // offsets below assume a 2-digit serial (delta=0)
    const off = (n) => n + delta;
    return {
        callType:     "OUTGOING",
        serial:       m[1],
        fromExt:      r.slice(off(7),  off(14)).trim(),
        trunk:        r.slice(off(14), off(18)).trim(),
        dialedNumber: r.slice(off(19), off(38)).trim(),
        date:         r.slice(off(38), off(46)).trim(),
        time:         r.slice(off(47), off(55)).trim(),
        duration:     r.slice(off(55), off(61)).trim(),
        units:        r.slice(off(61), off(66)).trim(),
        amount:       r.slice(off(66), off(74)).trim(),
        status:       r.slice(off(76)).trim(),
    };
}

function parseIC(r) {
    // The IC serial isn't padded to a fixed width either — it's just digits
    // followed by one space, so its length varies (1 digit early in the day,
    // 2-3+ later). Every downstream field must be offset from that space, not
    // from a hardcoded absolute column, or a wide serial bleeds into the number.
    const sp   = r.indexOf(" ");
    const base = sp + 1;
    return {
        callType:       "INCOMING",
        serial:         r.slice(0, sp).trim(),
        callerNumber:   r.slice(base,      base + 13).trim(),
        trunk:          r.slice(base + 17, base + 21).trim(),
        connectedExt:   r.slice(base + 27, base + 29).trim(),
        date:           r.slice(base + 30, base + 38).trim(),
        time:           r.slice(base + 41, base + 49).trim(),
        answerDuration: r.slice(base + 49, base + 53).trim(),
        holdDuration:   r.slice(base + 53, base + 57).trim(),
        speechDuration: r.slice(base + 57, base + 63).trim(),
        status:         r.slice(base + 64).trim(),
    };
}

function parseInternal(r) {
    return {
        callType: "INTERNAL",
        fromExt:  r.slice(11, 13).trim(),
        toExt:    r.slice(28, 30).trim(),
        date:     r.slice(40, 50).trim(),
        time:     r.slice(52, 60).trim(),
        duration: r.slice(60).trim(),
    };
}

// ── Log line formatter ────────────────────────────────────────────────────────
function formatLine(rec, raw) {
    const ts = new Date().toISOString();
    if (rec.callType === "OUTGOING") {
        const st = rec.status === "R" ? "ANSWERED" : rec.status === "U" ? "UNANSWERED" : rec.status;
        return `${ts} | OUTGOING  | Ext:${rec.fromExt.padEnd(6)} → ${rec.dialedNumber.padEnd(15)} | Trunk:${rec.trunk} | ${rec.date} ${rec.time} | Duration:${rec.duration.padStart(5)}s | Amt:${rec.amount} | ${st}\n`;
    }
    if (rec.callType === "INCOMING") {
        return `${ts} | INCOMING  | ${rec.callerNumber.padEnd(15)} → Ext:${rec.connectedExt} | Trunk:${rec.trunk} | ${rec.date} ${rec.time} | Speech:${rec.speechDuration.padStart(4)}s Answer:${rec.answerDuration.padStart(3)}s Hold:${rec.holdDuration.padStart(3)}s\n`;
    }
    if (rec.callType === "INTERNAL") {
        return `${ts} | INTERNAL  | Ext:${rec.fromExt} → Ext:${rec.toExt} | ${rec.date} ${rec.time} | Duration:${rec.duration.padStart(4)}s\n`;
    }
    return `${ts} | UNKNOWN   | ${raw}\n`;
}

function appendLog(file, text) {
    fs.appendFile(file, text, (err) => { if (err) console.error(`[EPBX][LOG] ${err.message}`); });
}

// ── CRM HTTP POST ─────────────────────────────────────────────────────────────
function postToCRM(crm, rec, attempt) {
    if (!crm.enabled || !crm.url) return;
    attempt = attempt || 1;

    const body    = JSON.stringify({ ...rec, timestamp: new Date().toISOString(), sourceHost: SOURCE_HOST });
    const u       = new URL(crm.url);
    const isHttps = u.protocol === "https:";
    const options = {
        hostname: u.hostname,
        port:     u.port || (isHttps ? 443 : 80),
        path:     u.pathname + u.search,
        method:   "POST",
        headers:  {
            "Content-Type":   "application/json",
            "Content-Length": Buffer.byteLength(body),
            "x-api-key":      crm.apiKey || "",
        },
    };

    const lib = isHttps ? https : http;
    const req = lib.request(options, (res) => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
            console.log(`[EPBX][CRM] ${rec.callType} posted (HTTP ${res.statusCode})`);
        } else {
            console.warn(`[EPBX][CRM] HTTP ${res.statusCode} — attempt ${attempt}`);
            if (attempt < crm.retryCount) setTimeout(() => postToCRM(crm, rec, attempt + 1), 3000);
        }
        res.resume();
    });
    req.on("error", (err) => {
        console.error(`[EPBX][CRM] ${err.message} — attempt ${attempt}`);
        if (attempt < crm.retryCount) setTimeout(() => postToCRM(crm, rec, attempt + 1), 3000);
    });
    req.write(body);
    req.end();
}

// ── Core record processor ─────────────────────────────────────────────────────
function processRecord(ctx, rawLine) {
    const raw = rawLine.replace(/[\r\n]+/g, "").trim();
    if (!raw) return;

    appendLog(ctx.rawLog, `${new Date().toISOString()} | ${raw}\n`);

    const type = detectType(raw);
    let rec;
    if      (type === "og")       rec = parseOG(raw);
    else if (type === "ic")       rec = parseIC(raw);
    else if (type === "internal") rec = parseInternal(raw);
    else                          rec = { callType: "UNKNOWN" };

    const line = formatLine(rec, raw);
    appendLog(ctx.callsLog, line);
    process.stdout.write("EPBX | " + line);

    // Include the raw SMDR line: the CRM uses it as the idempotency key (dedupe
    // across retries / multiple PCs / buffered replays) and it's the only content
    // an UNKNOWN record carries.
    postToCRM(ctx.crm, { ...rec, raw });
}

// ── TCP connection handler ────────────────────────────────────────────────────
function handleConnection(ctx, socket) {
    const addr = `${socket.remoteAddress}:${socket.remotePort}`;
    console.log(`[EPBX][CONNECT] ${addr}`);
    appendLog(ctx.callsLog, `\n--- Session ${addr}  ${new Date().toISOString()} ---\n`);

    let buf = Buffer.alloc(0), postingMode = false;

    socket.on("data", (chunk) => {
        buf = Buffer.concat([buf, chunk]);

        if (!postingMode && buf.length >= 1 && buf[0] === ENQ) {
            postingMode = true;
            buf = buf.slice(1);
            socket.write(Buffer.from([ACK]));
            return;
        }

        if (postingMode) {
            if (buf.length === 1 && buf[0] === EOT) { postingMode = false; buf = Buffer.alloc(0); return; }
            const stx = buf.indexOf(STX), etx = buf.indexOf(ETX, stx + 1);
            if (stx === -1 || etx === -1) return;
            const payload = buf.slice(stx + 1, etx).toString("ascii");
            let bcc = 0;
            for (let i = stx; i <= etx; i++) bcc ^= buf[i];
            const rxBcc = buf.length > etx + 1 ? buf[etx + 1] : bcc;
            socket.write(Buffer.from([rxBcc === bcc ? ACK : NAK]));
            if (rxBcc === bcc) processRecord(ctx, payload);
            buf = buf.slice(etx + 2);
            return;
        }

        let nl;
        while ((nl = buf.indexOf(0x0a)) !== -1) {
            processRecord(ctx, buf.slice(0, nl).toString("ascii"));
            buf = buf.slice(nl + 1);
        }
    });

    socket.on("close", () => {
        console.log(`[EPBX][DISCONNECT] ${addr}`);
        appendLog(ctx.callsLog, `--- Closed ${addr}  ${new Date().toISOString()} ---\n`);
    });
    socket.on("error", (err) => console.error(`[EPBX][SOCKET] ${addr}: ${err.message}`));
}

// ── Module entry — booted by index.js like thermal / qr ───────────────────────
function start({ getConfig }) {
    const cfg = getConfig() || {};
    const pbx  = { host: "0.0.0.0", port: 5000, ...(cfg.pbx  || {}) };
    const crm  = { enabled: false, url: "", apiKey: "", retryCount: 3, ...(cfg.crm || {}) };
    const logs = { callsLog: "calls.log", rawLog: "calls_raw.log", ...(cfg.logs || {}) };

    const ctx = {
        crm,
        callsLog: path.join(__dirname, logs.callsLog),
        rawLog:   path.join(__dirname, logs.rawLog),
    };

    const server = net.createServer((socket) => handleConnection(ctx, socket));

    server.on("error", (err) => {
        console.error(`[EPBX][ERROR] ${err.message}`);
        if (err.code === "EADDRINUSE") console.error(`[EPBX] Port ${pbx.port} already in use.`);
        // Don't kill the whole bridge (thermal/qr keep serving) — just log.
    });

    server.listen(pbx.port, pbx.host, () => {
        const hdr = `[EPBX] Matrix SMDR listener on ${pbx.host}:${pbx.port}  |  CRM: ${crm.enabled ? crm.url : "disabled"}`;
        appendLog(ctx.callsLog, `\n${"=".repeat(60)}\n${hdr}  ${new Date().toISOString()}\n${"=".repeat(60)}\n`);
        console.log(hdr);
    });
}

module.exports = { start };
