@echo off
REM ============================================================================
REM  update.bat  -  Update the bridge in place (double-click inside the install
REM  folder). Compares the installed version against the office app; if newer,
REM  stops the relay, refreshes the code + dependencies, and restarts. Keeps
REM  config.json. No admin needed (the scheduled task is untouched). Needs net.
REM ============================================================================
setlocal
cd /d "%~dp0"
REM https://office.networkservice.in is replaced with the real domain by the installer build (build.ps1).
set "APP=https://office.networkservice.in"

REM --- Version check: exit 10 = already latest, 1 = server unreachable ---------
echo Checking for updates...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { $r=(Invoke-RestMethod '%APP%/combined-bridge.version.json' -TimeoutSec 15).version } catch { Write-Host '  Could not reach %APP%'; exit 1 }; $l='unknown'; try { $l=(Invoke-RestMethod 'http://localhost:9191/health' -TimeoutSec 3).version } catch {}; Write-Host ('  Installed: ' + $l + '    Latest: ' + $r); if ($l -eq $r) { exit 10 } else { exit 0 }"
set "RC=%ERRORLEVEL%"
if "%RC%"=="10" ( echo. & echo Already up to date. & pause & exit /b 0 )
if "%RC%"=="1"  ( echo. & echo Update skipped - relay left as-is. & pause & exit /b 1 )

echo Stopping bridge...
call "%~dp0stop.bat"

echo Clearing old dependencies...
if exist "%~dp0node_modules" rmdir /s /q "%~dp0node_modules"

echo Downloading latest bridge...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; $z=Join-Path $env:TEMP 'cb-upd.zip'; $t=Join-Path $env:TEMP 'cb-upd'; Invoke-WebRequest '%APP%/combined-bridge.zip' -OutFile $z; if(Test-Path $t){Remove-Item $t -Recurse -Force}; Expand-Archive $z $t -Force; Copy-Item (Join-Path $t 'combined-bridge\*') '%~dp0' -Recurse -Force; Remove-Item $z,$t -Recurse -Force"
if errorlevel 1 ( echo. & echo Download failed - relay left as-is. & pause & exit /b 1 )

echo Reinstalling dependencies...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1"
if errorlevel 1 ( echo. & echo Dependency setup FAILED - bridge not restarted. & pause & exit /b 1 )

echo Restarting bridge...
wscript.exe //B "%~dp0start-hidden.vbs"

echo.
echo Update complete.
pause

