@echo off
REM ============================================================================
REM  update.bat  -  Update the bridge in place (double-click inside the install
REM  folder). Stops the relay, deletes node_modules, downloads the latest code
REM  from the office app, reinstalls deps (pnpm/npm via bootstrap), restarts.
REM  Keeps config.json. No admin needed: the scheduled task already exists and
REM  points at start-hidden.vbs, so we don't re-register it. Needs internet.
REM ============================================================================
setlocal
cd /d "%~dp0"
REM https://office.networkservice.in is replaced with the real domain by the installer build (build.ps1).
set "APP=https://office.networkservice.in"

echo Stopping bridge...
call "%~dp0stop.bat"

echo Clearing old dependencies...
if exist "%~dp0node_modules" rmdir /s /q "%~dp0node_modules"

echo Downloading latest bridge from %APP% ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; $z=Join-Path $env:TEMP 'cb-upd.zip'; $t=Join-Path $env:TEMP 'cb-upd'; Invoke-WebRequest '%APP%/combined-bridge.zip' -OutFile $z; if(Test-Path $t){Remove-Item $t -Recurse -Force}; Expand-Archive $z $t -Force; Copy-Item (Join-Path $t 'combined-bridge\*') '%~dp0' -Recurse -Force; Remove-Item $z,$t -Recurse -Force"
if errorlevel 1 ( echo. & echo Update failed ^(no internet?^). Relay left as-is. & pause & exit /b 1 )

echo Reinstalling dependencies...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1"
if errorlevel 1 ( echo. & echo Dependency setup FAILED - bridge not restarted. & pause & exit /b 1 )

echo Restarting bridge...
wscript.exe //B "%~dp0start-hidden.vbs"

echo.
echo Update complete.
pause

