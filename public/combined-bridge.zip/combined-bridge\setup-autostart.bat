@echo off
REM -------------------------------------------------------------------------
REM  Combined Bridge - Windows autostart installer (interactive / double-click)
REM
REM  Registers a Task Scheduler entry that launches the bridge hidden on every
REM  logon, then starts it now. No admin required for a per-user ONLOGON task.
REM  Idempotent - re-running overwrites. Undo with remove-autostart.bat.
REM -------------------------------------------------------------------------

setlocal
set "TASK=Combined Bridge"
set "VBS=%~dp0start-hidden.vbs"

if not exist "%VBS%" (
    echo ERROR: start-hidden.vbs not found next to this batch file.
    pause
    exit /b 1
)

echo Registering scheduled task "%TASK%"...
schtasks /Create /TN "%TASK%" /TR "wscript.exe \"%VBS%\"" /SC ONLOGON /F >nul
if errorlevel 1 (
    echo.
    echo Failed to create scheduled task.
    pause
    exit /b 1
)

echo.
echo Done. The bridge will start automatically next time you log in.
echo.
echo Starting it now so you don't have to reboot...
schtasks /Run /TN "%TASK%" >nul
if errorlevel 1 (
    echo (Could not start immediately. Will run on next logon.)
) else (
    echo Bridge started. Test:
    echo   Thermal:  http://localhost:9191/health
    echo   QR:       http://localhost:9192/health
)
echo.
pause
