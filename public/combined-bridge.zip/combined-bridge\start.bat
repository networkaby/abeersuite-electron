@echo off
REM Start the bridge in a VISIBLE window (shows logs/errors) for troubleshooting.
REM Normal autostart uses start-hidden.vbs. Needs Node on PATH (installer sets it).
cd /d "%~dp0"
node index.js
pause
