@echo off
REM -------------------------------------------------------------------------
REM  register-autostart.bat  -  Non-interactive autostart registration.
REM  Creates a Task Scheduler ONLOGON entry that launches the bridge hidden on
REM  every logon, then starts it now. No pause (safe to run hidden from the
REM  installer / update.bat). Idempotent - /F overwrites any existing task.
REM -------------------------------------------------------------------------
setlocal
set "TASK=Combined Bridge"
set "VBS=%~dp0start-hidden.vbs"

if not exist "%VBS%" exit /b 1

REM \" is the documented escaping for an inner quoted path in schtasks /TR.
schtasks /Create /TN "%TASK%" /TR "wscript.exe \"%VBS%\"" /SC ONLOGON /F >nul 2>&1
if errorlevel 1 exit /b 1

REM Start now so the user doesn't have to log off and on.
schtasks /Run /TN "%TASK%" >nul 2>&1
exit /b 0
