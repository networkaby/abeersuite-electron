# Architecture & repo relationships

This note explains **what `combined-bridge` is** and **how it relates to the two
other repos** it works with. For install steps and the HTTP API, see
[README.md](README.md).

## What this repo is

`combined-bridge` is the **runtime**. It is a single Node.js process that runs on
the **shop/counter PC** and does three things a browser cannot:

- **Thermal printer (ESC/POS)** → inbound `http://localhost:9191`
- **DQ11 QR display** (320×480 USB LCD) → inbound `http://localhost:9192`
- **Matrix ePBX call log (SMDR)** → inbound **TCP** `:5000`, pushed OUT to the
  cloud CRM (`/api/calls`)

All three live in one process (`index.js` → `thermal.js` + `qr.js` + `epbx.js`),
share one `config.json` (a slice each: `thermal` / `qr` / `epbx`), one autostart
task, and one set of dependencies. The first two are **inbound relays** — the web
app's browser POSTs print/display jobs to those `localhost` ports and the bridge
drives the hardware over LAN / COM / Windows print spooler. The third is the
**opposite direction**: the PBX box connects IN over raw TCP and streams call
records, which `epbx.js` parses and POSTs OUT to the cloud (`x-api-key` auth). It
has no npm dependencies (Node built-ins only).

This repo holds **only the runtime code and its run scripts** (`start.bat`,
`setup-autostart.bat`, etc.). It does **not** build installers and it is **not**
the web app.

## The three repos

```
  combined-bridge                 bridge-installer                service-mgmt-experiment
  (this repo — runtime)           (packager)                      (cloud web app)
  ───────────────────             ────────────────                ───────────────────────
  index.js / thermal.js / qr.js   build.config.json               public/  (serves installer)
  run + autostart scripts   ─┐    build.ps1 + .iss          ┌─►   Printer / QR Settings pages
  config.json (local only)   │    reads source, bundles it  │     browser → localhost:9191/9192
                             └──► builds ───────────────────┘
                                  setup.exe / setup-offline.exe
                                  combined-bridge.zip
                                  combined-bridge.version.json
```

### 1. `combined-bridge` → `bridge-installer`  (source → package)

`bridge-installer` is a **separate packaging repo**. At build time it reads this
repo as its `sourceRepo` (relative path `../combined-bridge` in its
`build.config.json`) and bundles this runtime into release artifacts:

- `combined-bridge-setup.exe` — online installer (fetches Node + deps at install)
- `combined-bridge-setup-offline.exe` — offline installer (bundles Node + deps)
- `combined-bridge.zip` — code-only payload used by the in-folder `update.bat`
- `combined-bridge.version.json` — the app's "update available" check

The **version must stay in sync**: this repo's `package.json` `version` and
`bridge-installer`'s `build.config.json` `version` are both **1.4.0** today. Bump
both together when releasing.

> Note: **`bridge-installer` is the single supported install path** for a counter
> PC (offline installer). Copying this folder by hand still works for dev/testing,
> but production PCs are set up via the installer.

### 2. `bridge-installer` → `service-mgmt-experiment`  (package → app)

`bridge-installer` writes its outputs straight into the web app's `public/`
folder (`onlineOutput` / `offlineOutput` both point at
`../../service-mgmt-experiment/public`). So after a build you commit and deploy
**the web app** to publish the new installer + version manifest.

### 3. `service-mgmt-experiment` ↔ `combined-bridge`  (app ↔ runtime, at run time)

Once installed on a counter PC, the app and this bridge talk directly on
`localhost`:

- The app's **Printer Settings** / **QR Display Settings** pages read and write
  config via `GET`/`POST /config` on ports 9191 / 9192 (the bridge maps each flat
  object onto its slice of `config.json`).
- The app's **browser** POSTs print jobs (`/print`, `/print/pos`) and display jobs
  (`/pos/customer`, `/pos/upi`, `/pos/thankyou`, …) to the two ports.
- The app shows an **"update available"** banner by comparing the counter's running
  version (from `/health`) against `combined-bridge.version.json` it serves.

The app never reaches the hardware itself — every print or QR-display action goes
through this bridge on the counter PC.

## Config lives on the PC, not in git

`config.json` (printer IP/COM, DQ11 COM port, UPI VPA, idle folder) is
**gitignored** — it is per-PC and stays on the shop machine. The committed
`config.json` in this repo, if any, is only a sample; real values are set through
the app's settings pages or edited on the PC.

## Release checklist (quick reference)

1. Change runtime code here in `combined-bridge`; bump `package.json` `version`.
2. In `bridge-installer`: bump `build.config.json` `version` to match, then
   `powershell -ExecutionPolicy Bypass -File build.ps1`.
3. In `service-mgmt-experiment`: commit the changed `public/*` and deploy.
4. On each counter PC: the app's Printer Settings shows "update available" →
   re-download and run the installer.
